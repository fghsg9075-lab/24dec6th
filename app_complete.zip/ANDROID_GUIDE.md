# 📱 How to Make APK (Android App) / APK कैसे बनाएं

भाई, मैंने आपके प्रोजेक्ट में "Capacitor Engine" लगा दिया है। अब यह वेब ऐप एक Android App बनने के लिए तैयार है।

चूँकि यह कोडिंग एनवायरनमेंट है, यहाँ से सीधा APK डाउनलोड नहीं हो सकता (इसके लिए Android Studio नाम का भारी सॉफ्टवेयर चाहिए होता है)।

लेकिन चिंता मत करो! आपको बस अपने कंप्यूटर (Laptop/PC) पर ये स्टेप्स फॉलो करने हैं:

### ✅ Step 1: सॉफ़्टवेयर डाउनलोड करें (Download Prerequisites)
1.  **Node.js** डाउनलोड करें और इनस्टॉल करें (अगर नहीं है): [nodejs.org](https://nodejs.org/)
2.  **Android Studio** डाउनलोड करें और इनस्टॉल करें: [developer.android.com/studio](https://developer.android.com/studio)

### ✅ Step 2: कोड अपने कंप्यूटर पर लाएं (Get Code)
इस प्रोजेक्ट को डाउनलोड करें (Download Zip) और अनज़िप करें। फिर उस फोल्डर में `Right Click` -> `Open in Terminal` (या CMD) करें।

### ✅ Step 3: कमांड चलाएं (Run Commands)
टर्मिनल (Terminal) में ये कमांड्स एक-एक करके लिखें और Enter दबाएं:

1.  लाइब्रेरी इनस्टॉल करें:
    ```bash
    npm install
    ```

2.  एंड्राइड फोल्डर बनाएं:
    ```bash
    npx cap add android
    ```

3.  कोड को एंड्राइड में डालें (Sync):
    ```bash
    npm run mobile:sync
    ```

4.  Android Studio खोलें:
    ```bash
    npx cap open android
    ```

### ✅ Step 4: APK जनरेट करें (Generate APK)
जैसे ही Android Studio खुलेगा:
1.  ऊपर मेनू में **"Build"** पर क्लिक करें।
2.  **"Build Bundle(s) / APK(s)"** चुनें।
3.  **"Build APK(s)"** पर क्लिक करें।

🎉 **बधाई हो!** कुछ ही देर में आपका APK तैयार हो जाएगा और आप उसे किसी भी फोन में चला पाएंगे।

---

### 🚀 आसान तरीका (Alternative: WebAPK)
अगर Android Studio बहुत भारी लग रहा है, तो आप इसे **PWA (Progressive Web App)** की तरह भी इस्तेमाल कर सकते हैं:
1.  इस कोड को Netlify या Vercel पर होस्ट करें।
2.  अपने मोबाइल के Chrome ब्राउज़र में लिंक खोलें।
3.  "Three Dots" (⋮) पर क्लिक करें -> **"Add to Home Screen"**।
4.  यह बिल्कुल ऐप जैसा दिखेगा और चलेगा!
